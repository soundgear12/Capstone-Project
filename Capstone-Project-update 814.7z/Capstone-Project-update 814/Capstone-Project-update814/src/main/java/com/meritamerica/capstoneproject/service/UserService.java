package com.meritamerica.capstoneproject.service;

import com.meritamerica.capstoneproject.models.User;

public interface UserService {
    public User registerUser(User user);
    public User getUser(int id);
    public User getUserByUserName(String username);
}
