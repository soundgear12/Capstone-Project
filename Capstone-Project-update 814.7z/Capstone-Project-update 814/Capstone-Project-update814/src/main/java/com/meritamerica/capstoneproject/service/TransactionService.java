package com.meritamerica.capstoneproject.service;

import com.meritamerica.capstoneproject.models.BankAccount;
import com.meritamerica.capstoneproject.models.Transaction;
import com.meritamerica.capstoneproject.models.WithdrawTransaction;

import javax.servlet.http.HttpServletRequest;
import java.util.List;

public interface TransactionService {
    public BankAccount postPersonalWithdraw(HttpServletRequest request, WithdrawTransaction withdrawTransaction, String txnType) throws Exception;
    public List<Transaction> getAllTransactions();
}
