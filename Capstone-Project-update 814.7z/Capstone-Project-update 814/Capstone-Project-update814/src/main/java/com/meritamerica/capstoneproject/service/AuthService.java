package com.meritamerica.capstoneproject.service;

import com.meritamerica.capstoneproject.models.AccountHolder;
import com.meritamerica.capstoneproject.securities.models.RegisterRequest;
import org.springframework.http.ResponseEntity;

import java.util.List;

public interface AuthService {
    public ResponseEntity<?> registerUser(RegisterRequest registerRequest);
    public AccountHolder addAccountHolder(AccountHolder accountHolder);
    public List<AccountHolder> getAccountHolders();
}
