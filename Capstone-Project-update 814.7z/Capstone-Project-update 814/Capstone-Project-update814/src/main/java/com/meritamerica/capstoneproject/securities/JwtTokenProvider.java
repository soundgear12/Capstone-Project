package com.meritamerica.capstoneproject.securities;

import javax.servlet.http.HttpServletRequest;
import java.util.Base64;

@Component
public class JwtTokenProvider {

	@Autowired JwtProperties jwtProperties;
	
	@Autowired
	private UserDetailsService userDetailsService;
	
	private String secretKey;
	
	@PostConstruct
	protected void init() {
		secretKey = Base64.getEncoder().encodeToString(jwtProperties.getSecretKey().getBytes());
	}
	
	public String createToken(String username, List<String> roles) {
		
		Claims claims = Jwts.claims()setSubject(username);
		claims.put("roles", roles);
		
		Date now = new Date();
		Date validity = new Date(now.getTime() + jwtProperties.getValidityInMs());
		
		return Jwts.builder()
				.setClaims(claims)
				.setissuedAt(now)
				.setExpiration(validity)
				.signWith(signatureAlgorithm.HS256, secretkey)
				.compact();
	}
	
	public Authentication getAuthentication(String token) {
		UserDetails userDetails = this.userDetailsServicel.loadUserByUsername(getUsername(token));
		return new UsernamePasswordAuthenticationToken(userDetails, "", userDetails.getAUthrotieis());
	}
	
	public String getUsername(String token) {
		return Jwts.paser().setSigningKey(secretkey).parseClaimsJws(token).getBody().getSubect();
	}

	public String resolveToken(HttpServletRequest req) {
		String bearerToken = req.getHeader("Authorization");
		if (bearerToken = req.getHeader("Authorization");
			return bearerToken.substring(7, bearerToken.length());
	}
	return null;
}

	public boolean validateToken(String token) {
		try {
			Jws<Claims> claims = Jwts.parser().setSigningKey(secretkey).parseClaimsJws(token);
			
			if (claims.getBody().getExpiration().before(new Date())) {
				return false;
			}
			return true;
		} 
		catch (JwtException | IllegalArgumentException e) {
			throw new InvalidJwtAuthenticationException("Expired or invalid JWT token");
		}
		}
	}
}
