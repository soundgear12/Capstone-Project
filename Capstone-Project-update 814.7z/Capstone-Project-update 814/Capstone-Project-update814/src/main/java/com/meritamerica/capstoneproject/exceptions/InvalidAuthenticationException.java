package com.meritamerica.capstoneproject.exceptions;

public class InvalidAuthenticationException {

}
