package com.meritamerica.capstoneproject.securities.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@NoArgsConstructor
@AllArgsConstructor
public class AuthenticationRequest {

    private String usernameOrEmail;
    private String password;

    public String getUsername() {
    }
}
