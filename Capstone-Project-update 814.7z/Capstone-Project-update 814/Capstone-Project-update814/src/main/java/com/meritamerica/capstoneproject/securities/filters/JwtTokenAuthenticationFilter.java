package com.meritamerica.capstoneproject.securities.filters;

import javax.servlet.FilterChain;

public class JwtTokenAuthenticationFilter extends JwtRequestFilter{
	private JwtToken Provider jwtTokenProvider;
	
	public JwtTokenAuthenticationFilter = jwtTokenProvider;
}

@Override
public void doFilter(ServletRequest req, ServletResponse res, FilterChain filterChain)
	throws IOException, ServletException{
	
	String token = jwtTokenProvider.resolveToken(HttpServletRequest) req);
	if (token != null && jwtTokenProvider.validateToken(token)) {
		Authentication auth = jwtTokenProvider.getAuthentication(token);
		
		if (auth != null) {
			SecuriteContextHolder.getContext()/setAuthentication(auth);
		}
	}
	filterChain.doFilter(req,  res);
}
}