package com.meritamerica.capstoneproject.securities.models;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
public class AuthenticationResponse {

    private final String jwt;
}
