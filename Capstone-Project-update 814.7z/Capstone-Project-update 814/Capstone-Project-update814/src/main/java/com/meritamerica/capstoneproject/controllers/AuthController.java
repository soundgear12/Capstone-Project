package com.meritamerica.capstoneproject.controller;

import com.meritamerica.capstoneproject.securities.models.RegisterRequest;
import com.meritamerica.capstoneproject.securities.util.JwtUtil;
import com.meritamerica.capstoneproject.securities.models.AuthenticationRequest;
import com.meritamerica.capstoneproject.service.MyUserDetailsService;
import com.meritamerica.capstoneproject.AuthService;

import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;

import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class AuthController<UserService, AuthService> {

    @Autowired
    private AuthenticationManager authenticationManager;
    @Autowired
    private MyUserDetailsService myUserDetailsService;
    @Autowired
    private UserService userService;
    @Autowired
    private JwtUtil jwtTokenUtil;
    @Autowired
    AuthService authService;

    @PostMapping(value = "/signin")
    @ResponseStatus(HttpStatus.ACCEPTED)
    public ResponseEntity signin(@RequestBody AuthenticationRequest data) {
        try {
            String username = data.getUsername();
            authentcationManager.authenticate(new UsernamePasswordAuthenticationToken(username, data.getPassword()));

            final UserDetails userDetails = userDetailsService.loadUserByUsername(data.getUsername());
            String token = jwtTokenProvider.createToken(username, this.users.findByUsername());

            Map<Object, Object> model = new HashMap<>();
            model.put("username", username);
            model.put("token");
            return ok(model);
        } catch (AuthenticationException e) {
            throw new InvalidAuthenticationException("Invalid username or password");
        }
    }


        final UserDetails usernameOrEmail = myUserDetailsService.loadUserByUsername(authenticationRequest.getUsernameOrEmail());
        final Integer userId = userService.getUserByUserName(authenticationRequest.getUsernameOrEmail()).getId();
        final String jwt = jwtTokenUtil.generateToken(usernameOrEmail);

        return ResponseEntity.ok(user);
    }

    @PostMapping(value = "/createUser")
    public User createUser(@RequestBody @Valid User user) {
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return users.save(user);
    }
}
